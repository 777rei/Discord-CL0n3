"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import { useChatStore } from "@/stores/chat-store";

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
  ],
};

interface UseWebRTCProps {
  getSocket: () => any;
  channelId: string | null;
}

export function useWebRTC({ getSocket, channelId }: UseWebRTCProps) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);

  const peerConnections = useRef<Map<string, RTCPeerConnection>>(new Map());
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);

  const { userId } = useChatStore();

  const createPeerConnection = useCallback(
    (peerSocketId: string) => {
      if (peerConnections.current.has(peerSocketId)) {
        return peerConnections.current.get(peerSocketId)!;
      }

      const pc = new RTCPeerConnection(ICE_SERVERS);

      pc.onicecandidate = (event) => {
        if (event.candidate && channelId) {
          const socket = getSocket();
          socket?.emit("webrtc-ice-candidate", {
            channelId,
            targetSocketId: peerSocketId,
            candidate: event.candidate.toJSON(),
          });
        }
      };

      pc.ontrack = (event) => {
        setRemoteStreams((prev) => {
          const next = new Map(prev);
          next.set(peerSocketId, event.streams[0]);
          return next;
        });
      };

      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === "disconnected" || pc.iceConnectionState === "failed") {
          peerConnections.current.delete(peerSocketId);
          setRemoteStreams((prev) => {
            const next = new Map(prev);
            next.delete(peerSocketId);
            return next;
          });
        }
      };

      // Add local tracks
      const stream = localStreamRef.current;
      if (stream) {
        stream.getTracks().forEach((track) => {
          pc.addTrack(track, stream);
        });
      }

      peerConnections.current.set(peerSocketId, pc);
      return pc;
    },
    [channelId, getSocket]
  );

  const startLocalStream = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      localStreamRef.current = stream;
      setLocalStream(stream);
      return stream;
    } catch (error) {
      console.error("Failed to get local stream:", error);
      // Try audio only
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: false,
          audio: true,
        });
        localStreamRef.current = stream;
        setLocalStream(stream);
        return stream;
      } catch (audioError) {
        console.error("Failed to get audio stream:", audioError);
        return null;
      }
    }
  }, []);

  const stopLocalStream = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
      setLocalStream(null);
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;
    }
    peerConnections.current.forEach((pc) => pc.close());
    peerConnections.current.clear();
    setRemoteStreams(new Map());
    setIsScreenSharing(false);
  }, []);

  const toggleMute = useCallback(() => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  }, [isMuted]);

  const toggleVideo = useCallback(() => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  }, [isVideoOff]);

  const startScreenSharing = useCallback(async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
      });

      screenStreamRef.current = screenStream;

      // Replace video track in all peer connections
      const screenTrack = screenStream.getVideoTracks()[0];
      peerConnections.current.forEach((pc) => {
        const senders = pc.getSenders();
        const videoSender = senders.find((s) => s.track?.kind === "video");
        if (videoSender) {
          videoSender.replaceTrack(screenTrack);
        }
      });

      screenTrack.onended = () => {
        // Switch back to camera
        if (localStreamRef.current) {
          const cameraTrack = localStreamRef.current.getVideoTracks()[0];
          peerConnections.current.forEach((pc) => {
            const senders = pc.getSenders();
            const videoSender = senders.find((s) => s.track?.kind === "video");
            if (videoSender && cameraTrack) {
              videoSender.replaceTrack(cameraTrack);
            }
          });
        }
        screenStreamRef.current = null;
        setIsScreenSharing(false);
        const socket = getSocket();
        if (socket && channelId) {
          socket.emit("screen-share-stop", { channelId });
        }
      };

      setIsScreenSharing(true);
      const socket = getSocket();
      if (socket && channelId) {
        socket.emit("screen-share-start", { channelId });
      }
    } catch (error) {
      console.error("Failed to start screen sharing:", error);
    }
  }, [channelId, getSocket]);

  const stopScreenSharing = useCallback(() => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;

      // Switch back to camera
      if (localStreamRef.current) {
        const cameraTrack = localStreamRef.current.getVideoTracks()[0];
        peerConnections.current.forEach((pc) => {
          const senders = pc.getSenders();
          const videoSender = senders.find((s) => s.track?.kind === "video");
          if (videoSender && cameraTrack) {
            videoSender.replaceTrack(cameraTrack);
          }
        });
      }

      setIsScreenSharing(false);
      const socket = getSocket();
      if (socket && channelId) {
        socket.emit("screen-share-stop", { channelId });
      }
    }
  }, [channelId, getSocket]);

  // Handle incoming WebRTC signals via registerWebRTCListeners
  const setupWebRTCSignaling = useCallback(
    (registerWebRTCListeners: (handlers: any) => () => void) => {
      const cleanup = registerWebRTCListeners({
        onOffer: async (data: {
          channelId: string;
          fromSocketId: string;
          offer: RTCSessionDescriptionInit;
        }) => {
          if (data.channelId !== channelId) return;

          const pc = createPeerConnection(data.fromSocketId);
          await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);

          const socket = getSocket();
          socket?.emit("webrtc-answer", {
            channelId: data.channelId,
            targetSocketId: data.fromSocketId,
            answer,
          });
        },

        onAnswer: async (data: {
          channelId: string;
          fromSocketId: string;
          answer: RTCSessionDescriptionInit;
        }) => {
          if (data.channelId !== channelId) return;

          const pc = peerConnections.current.get(data.fromSocketId);
          if (pc) {
            await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
          }
        },

        onIceCandidate: async (data: {
          channelId: string;
          fromSocketId: string;
          candidate: RTCIceCandidateInit;
        }) => {
          if (data.channelId !== channelId) return;

          const pc = peerConnections.current.get(data.fromSocketId);
          if (pc) {
            await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
          }
        },

        onUserJoinedVideo: async (data: {
          channelId: string;
          user: { socketId: string; userId: string; username: string; displayName: string };
        }) => {
          if (data.channelId !== channelId) return;

          // Create offer for the new user
          const pc = createPeerConnection(data.user.socketId);
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);

          const socket = getSocket();
          socket?.emit("webrtc-offer", {
            channelId: data.channelId,
            targetSocketId: data.user.socketId,
            offer,
          });
        },
      });

      return cleanup;
    },
    [channelId, createPeerConnection, getSocket]
  );

  return {
    localStream,
    remoteStreams,
    isMuted,
    isVideoOff,
    isScreenSharing,
    startLocalStream,
    stopLocalStream,
    toggleMute,
    toggleVideo,
    startScreenSharing,
    stopScreenSharing,
    setupWebRTCSignaling,
  };
}
