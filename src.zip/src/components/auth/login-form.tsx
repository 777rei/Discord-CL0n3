"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Loader2, LogIn } from "lucide-react";

interface LoginFormProps {
  onSuccess: () => void;
  onSwitchToRegister: () => void;
}

export function LoginForm({ onSuccess, onSwitchToRegister }: LoginFormProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.trim() || !password.trim()) {
      setError("Please fill in all fields");
      return;
    }

    setIsLoading(true);

    try {
      const result = await signIn("credentials", {
        email: email.trim(),
        password,
        redirect: false,
      });

      if (result?.error) {
        setError("Invalid email or password");
        setIsLoading(false);
        return;
      }

      if (result?.ok) {
        onSuccess();
      } else {
        setError("Login failed. Please try again.");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-[480px]">
      <Card className="border-0 bg-[#313338] shadow-2xl">
        <CardHeader className="items-center text-center">
          <div className="mb-2 flex h-[86px] w-[130px] items-center justify-center">
            <svg
              width="130"
              height="86"
              viewBox="0 0 130 86"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M107.7 13.4C99.4 6.6 87.4 2.6 87.4 2.6L87.2 2.8C77.8 0.9 68.3 0 58.8 0C49.3 0 39.8 0.9 30.4 2.8L30.2 2.6C30.2 2.6 18.2 6.6 9.9 13.4C-4.3 38.4 -0.2 63.8 2.3 68.5C2.3 68.5 16.4 83.5 38.5 83.5L43.6 74.8C35.1 72 27.1 67.6 20 61.7L23.4 65.1C32.5 71.3 43.5 74.8 55 74.8C66.5 74.8 77.5 71.3 86.6 65.1L90 61.7C82.9 67.6 74.9 72 66.4 74.8L71.5 83.5C93.6 83.5 107.7 68.5 107.7 68.5C110.2 63.8 114.3 38.4 100.1 13.4H107.7Z"
                fill="#23a559"
              />
            </svg>
          </div>
          <CardTitle className="text-2xl font-bold text-white">
            Welcome back!
          </CardTitle>
          <CardDescription className="text-[#b5bac1]">
            We&apos;re so excited to see you again!
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="rounded-md bg-[#f23f42]/10 px-4 py-3 text-sm text-[#f23f42]">
                {error}
              </div>
            )}

            <div className="space-y-2">
              <Label
                htmlFor="login-email"
                className="text-xs font-bold uppercase tracking-wide text-[#b5bac1]"
              >
                Email
                <span className="ml-0.5 text-[#f23f42]">*</span>
              </Label>
              <Input
                id="login-email"
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-10 border-0 bg-[#1e1f22] text-white placeholder:text-[#72767d] focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="login-password"
                className="text-xs font-bold uppercase tracking-wide text-[#b5bac1]"
              >
                Password
                <span className="ml-0.5 text-[#f23f42]">*</span>
              </Label>
              <Input
                id="login-password"
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-10 border-0 bg-[#1e1f22] text-white placeholder:text-[#72767d] focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="h-10 w-full bg-[#23a559] text-white hover:bg-[#1a8f48] active:bg-[#17803f] disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Logging in...
                </>
              ) : (
                <>
                  <LogIn className="size-4" />
                  Log In
                </>
              )}
            </Button>

            <p className="pt-2 text-sm text-[#949ba4]">
              Don&apos;t have an account?{" "}
              <button
                type="button"
                onClick={onSwitchToRegister}
                className="text-sm text-[#00a8fc] hover:underline"
              >
                Register
              </button>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
