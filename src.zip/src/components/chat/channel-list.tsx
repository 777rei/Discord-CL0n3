"use client";

import { useState } from "react";
import { useChatStore } from "@/stores/chat-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Hash,
  Volume2,
  Plus,
  ChevronDown,
  ChevronRight,
  Settings,
  User,
  LogOut,
  Video,
  UserPlus,
  Copy,
  Check,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function ChannelList() {
  const {
    servers,
    activeServerId,
    activeChannelId,
    setActiveChannel,
    userId,
    username,
    displayName,
  } = useChatStore();

  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [channelType, setChannelType] = useState("text");
  const [creating, setCreating] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [showInvite, setShowInvite] = useState(false);
  const [copied, setCopied] = useState(false);

  const activeServer = servers.find((s) => s.id === activeServerId);

  const textChannels =
    activeServer?.channels.filter((c) => c.type === "text") || [];
  const voiceChannels =
    activeServer?.channels.filter((c) => c.type === "voice") || [];

  const handleCreateChannel = async () => {
    if (!channelName.trim() || !activeServerId) return;
    setCreating(true);
    try {
      const res = await fetch(
        `/api/servers/${activeServerId}/channels`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: channelName.trim(), type: channelType }),
        }
      );
      if (res.ok) {
        const channel = await res.json();
        // Refresh servers
        const serversRes = await fetch("/api/servers");
        if (serversRes.ok) {
          const servers = await serversRes.json();
          useChatStore.getState().setServers(servers);
        }
        setChannelName("");
        setShowCreateChannel(false);
      }
    } catch (err) {
      console.error("Create channel error:", err);
    } finally {
      setCreating(false);
    }
  };

  const handleSignOut = async () => {
    await fetch("/api/auth/callback/credentials", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "signout" }),
    });
    // Force sign out by clearing session
    window.location.href = "/api/auth/signout";
  };

  if (!activeServer) {
    // No server selected - show DM / home view
    return (
      <div className="w-60 bg-[#2b2d31] flex flex-col shrink-0">
        <div className="h-12 px-4 flex items-center border-b border-[#1f2023] shadow-sm">
          <span className="font-semibold text-white text-[15px]">
            Direct Messages
          </span>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2">
            <div className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-[#35373c] cursor-pointer text-[#949ba4]">
              <User className="w-5 h-5" />
              <span className="text-sm">{displayName || username}</span>
            </div>
          </div>
        </ScrollArea>
        {/* User panel at bottom */}
        <div className="h-[52px] bg-[#232428] px-2 flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[#23a559] flex items-center justify-center text-white text-xs font-bold">
            {(displayName || username)?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {displayName}
            </p>
            <p className="text-[11px] text-[#949ba4] truncate">Online</p>
          </div>
          <button
            onClick={handleSignOut}
            className="p-1 rounded hover:bg-[#35373c] text-[#949ba4] hover:text-white"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-60 bg-[#2b2d31] flex flex-col shrink-0">
      {/* Server name header with dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <div className="h-12 px-4 flex items-center border-b border-[#1f2023] shadow-sm cursor-pointer hover:bg-[#35373c] transition-colors">
            <span className="font-semibold text-white text-[15px] flex-1 truncate">
              {activeServer.name}
            </span>
            <ChevronDown className="w-4 h-4 text-[#949ba4]" />
          </div>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="bg-[#111214] text-white border-[#2b2d31] w-56">
          <DropdownMenuItem
            className="focus:bg-[#4752c4] cursor-pointer text-[#23a559]"
            onClick={() => setShowInvite(true)}
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Invite People
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#2b2d31]" />
          <DropdownMenuItem
            className="focus:bg-[#4752c4] cursor-pointer"
            onClick={() => {
              navigator.clipboard.writeText(activeServer.inviteCode || "");
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? (
              <Check className="w-4 h-4 mr-2 text-[#23a559]" />
            ) : (
              <Copy className="w-4 h-4 mr-2" />
            )}
            {copied ? "Copied!" : "Copy Invite Code"}
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#2b2d31]" />
          <DropdownMenuItem className="focus:bg-[#4752c4] cursor-pointer text-[#949ba4]">
            <Settings className="w-4 h-4 mr-2" />
            Server Settings
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Invite Dialog */}
      <Dialog open={showInvite} onOpenChange={setShowInvite}>
        <DialogContent className="bg-[#313338] text-white border-none">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-bold">
              Invite Friends to {activeServer.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-sm text-[#949ba4] text-center">
              Share this invite code with your friends so they can join your server!
            </p>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-[#1e1f22] rounded px-3 py-2.5 text-sm font-mono text-[#dbdee1] select-all border border-[#383a40]">
                {activeServer.inviteCode}
              </div>
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(activeServer.inviteCode || "");
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className={`${
                  copied ? "bg-[#23a559]" : "bg-[#4752c4] hover:bg-[#3c45a5]"
                } text-white shrink-0`}
              >
                {copied ? (
                  <Check className="w-4 h-4 mr-1" />
                ) : (
                  <Copy className="w-4 h-4 mr-1" />
                )}
                {copied ? "Copied!" : "Copy"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-0.5">
          {/* Text Channels */}
          <div
            className="flex items-center gap-0.5 px-1 py-1.5 cursor-pointer group"
            onClick={() =>
              setCollapsed((prev) => ({
                ...prev,
                text: !prev.text,
              }))
            }
          >
            {collapsed.text ? (
              <ChevronRight className="w-3 h-3 text-[#949ba4]" />
            ) : (
              <ChevronDown className="w-3 h-3 text-[#949ba4]" />
            )}
            <span className="text-[11px] font-semibold text-[#949ba4] uppercase tracking-wide">
              Text Channels
            </span>
            <Dialog
              open={showCreateChannel}
              onOpenChange={setShowCreateChannel}
            >
              <DialogTrigger asChild>
                <Plus
                  className="w-4 h-4 text-[#949ba4] ml-auto opacity-0 group-hover:opacity-100 hover:text-white"
                  onClick={(e) => e.stopPropagation()}
                />
              </DialogTrigger>
              <DialogContent className="bg-[#313338] text-white border-none">
                <DialogHeader>
                  <DialogTitle className="text-center text-xl font-bold">
                    Create Channel
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-[#949ba4] uppercase">
                      Channel Type
                    </label>
                    <div className="space-y-2">
                      <button
                        className={`w-full p-3 rounded flex items-center gap-3 ${
                          channelType === "text"
                            ? "bg-[#404249] ring-1 ring-white"
                            : "bg-[#2b2d31] hover:bg-[#35373c]"
                        }`}
                        onClick={() => setChannelType("text")}
                      >
                        <Hash className="w-5 h-5" />
                        <div className="text-left">
                          <p className="font-medium">Text</p>
                          <p className="text-xs text-[#949ba4]">
                            Send messages, images, GIFs, emoji, opinions, puns
                          </p>
                        </div>
                      </button>
                      <button
                        className={`w-full p-3 rounded flex items-center gap-3 ${
                          channelType === "voice"
                            ? "bg-[#404249] ring-1 ring-white"
                            : "bg-[#2b2d31] hover:bg-[#35373c]"
                        }`}
                        onClick={() => setChannelType("voice")}
                      >
                        <Volume2 className="w-5 h-5" />
                        <div className="text-left">
                          <p className="font-medium">Voice</p>
                          <p className="text-xs text-[#949ba4]">
                            Hang out together with voice and video
                          </p>
                        </div>
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#949ba4] uppercase">
                      Channel Name
                    </label>
                    <div className="flex items-center bg-[#1e1f22] rounded mt-1 px-3">
                      {channelType === "text" ? (
                        <Hash className="w-4 h-4 text-[#949ba4]" />
                      ) : (
                        <Volume2 className="w-4 h-4 text-[#949ba4]" />
                      )}
                      <Input
                        placeholder="new-channel"
                        value={channelName}
                        onChange={(e) => setChannelName(e.target.value)}
                        className="border-none bg-transparent text-white focus-visible:ring-0"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={handleCreateChannel}
                    disabled={creating || !channelName.trim()}
                    className="w-full bg-[#23a559] hover:bg-[#1a8f4a] text-white"
                  >
                    {creating ? "Creating..." : "Create Channel"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {!collapsed.text &&
            textChannels.map((channel) => (
              <button
                key={channel.id}
                className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-sm group ${
                  activeChannelId === channel.id
                    ? "bg-[#404249] text-white"
                    : "text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]"
                }`}
                onClick={() => setActiveChannel(channel.id)}
              >
                <Hash className="w-5 h-5 shrink-0" />
                <span className="truncate">{channel.name}</span>
              </button>
            ))}

          {/* Voice Channels */}
          <div
            className="flex items-center gap-0.5 px-1 py-1.5 cursor-pointer group mt-2"
            onClick={() =>
              setCollapsed((prev) => ({
                ...prev,
                voice: !prev.voice,
              }))
            }
          >
            {collapsed.voice ? (
              <ChevronRight className="w-3 h-3 text-[#949ba4]" />
            ) : (
              <ChevronDown className="w-3 h-3 text-[#949ba4]" />
            )}
            <span className="text-[11px] font-semibold text-[#949ba4] uppercase tracking-wide">
              Voice Channels
            </span>
          </div>

          {!collapsed.voice &&
            voiceChannels.map((channel) => (
              <button
                key={channel.id}
                className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-sm group ${
                  activeChannelId === channel.id
                    ? "bg-[#404249] text-white"
                    : "text-[#949ba4] hover:text-[#dbdee1] hover:bg-[#35373c]"
                }`}
                onClick={() => setActiveChannel(channel.id)}
              >
                <Volume2 className="w-5 h-5 shrink-0" />
                <span className="truncate">{channel.name}</span>
              </button>
            ))}
        </div>
      </ScrollArea>

      {/* User panel at bottom */}
      <div className="h-[52px] bg-[#232428] px-2 flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-[#23a559] flex items-center justify-center text-white text-xs font-bold relative">
          {(displayName || username)?.[0]?.toUpperCase()}
          <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#23a559] rounded-full border-[3px] border-[#232428]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-white truncate">
            {displayName}
          </p>
          <p className="text-[11px] text-[#949ba4] truncate">Online</p>
        </div>
        <button
          onClick={handleSignOut}
          className="p-1 rounded hover:bg-[#35373c] text-[#949ba4] hover:text-white"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
