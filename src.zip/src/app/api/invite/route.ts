import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = (session.user as any).id;
    const body = await req.json();
    const { inviteCode } = body;

    if (!inviteCode) {
      return NextResponse.json(
        { error: "Invite code is required" },
        { status: 400 }
      );
    }

    const server = await db.server.findUnique({
      where: { inviteCode },
    });

    if (!server) {
      return NextResponse.json(
        { error: "Invalid invite code" },
        { status: 404 }
      );
    }

    // Check if already a member
    const existingMember = await db.member.findUnique({
      where: { userId_serverId: { userId, serverId: server.id } },
    });

    if (existingMember) {
      return NextResponse.json(
        { error: "You are already a member of this server" },
        { status: 409 }
      );
    }

    const member = await db.member.create({
      data: {
        userId,
        serverId: server.id,
        role: "member",
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            displayName: true,
            avatarUrl: true,
            status: true,
          },
        },
      },
    });

    return NextResponse.json({ server, member }, { status: 201 });
  } catch (error) {
    console.error("Join server error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
