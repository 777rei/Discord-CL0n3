"use client";

import { useState } from "react";
import { useChatStore } from "@/stores/chat-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Plus,
  Hash,
  MessageCircle,
  UserPlus,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

export function ServerList() {
  const { servers, activeServerId, setActiveServer, setActiveChannel } =
    useChatStore();
  const [showCreate, setShowCreate] = useState(false);
  const [serverName, setServerName] = useState("");
  const [creating, setCreating] = useState(false);

  const handleCreateServer = async () => {
    if (!serverName.trim()) return;
    setCreating(true);
    try {
      const res = await fetch("/api/servers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: serverName.trim() }),
      });
      if (res.ok) {
        const server = await res.json();
        useChatStore.getState().addServer(server);
        setActiveServer(server.id);
        if (server.channels?.[0]) {
          setActiveChannel(server.channels[0].id);
        }
        setServerName("");
        setShowCreate(false);
      }
    } catch (err) {
      console.error("Create server error:", err);
    } finally {
      setCreating(false);
    }
  };

  const [showJoin, setShowJoin] = useState(false);
  const [inviteCode, setInviteCode] = useState("");
  const [joining, setJoining] = useState(false);
  const [joinError, setJoinError] = useState("");
  const [joinSuccess, setJoinSuccess] = useState("");

  const handleJoinServer = async () => {
    if (!inviteCode.trim()) return;
    setJoining(true);
    setJoinError("");
    setJoinSuccess("");
    try {
      const res = await fetch("/api/invite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inviteCode: inviteCode.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        // Refresh servers
        const serversRes = await fetch("/api/servers");
        if (serversRes.ok) {
          const servers = await serversRes.json();
          useChatStore.getState().setServers(servers);
        }
        setActiveServer(data.server.id);
        setJoinSuccess(`Joined "${data.server.name}" successfully!`);
        setInviteCode("");
        // Close dialog after short delay
        setTimeout(() => {
          setShowJoin(false);
          setJoinSuccess("");
        }, 1500);
      } else {
        setJoinError(data.error || "Failed to join server");
      }
    } catch (err) {
      setJoinError("Something went wrong. Please try again.");
      console.error("Join server error:", err);
    } finally {
      setJoining(false);
    }
  };

  return (
    <div className="w-[72px] bg-[#1e1f22] flex flex-col items-center py-3 gap-2 shrink-0">
      {/* Home button */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center ${
                !activeServerId
                  ? "bg-[#23a559] rounded-[16px]"
                  : "bg-[#313338] hover:bg-[#23a559]"
              }`}
              onClick={() => {
                setActiveServer("");
                setActiveChannel("");
              }}
            >
              <MessageCircle
                className={`w-6 h-6 ${
                  !activeServerId ? "text-white" : "text-[#dbdee1]"
                }`}
              />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right">Direct Messages</TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <div className="w-8 h-[2px] bg-[#35363c] rounded-full" />

      {/* Server list */}
      <ScrollArea className="flex-1 w-full">
        <div className="flex flex-col items-center gap-2 px-3">
          {servers.map((server) => (
            <TooltipProvider key={server.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center text-sm font-semibold ${
                      activeServerId === server.id
                        ? "rounded-[16px] bg-[#23a559] text-white"
                        : "bg-[#313338] text-[#dbdee1] hover:bg-[#23a559] hover:text-white"
                    }`}
                    onClick={() => {
                      setActiveServer(server.id);
                      if (server.channels?.[0]) {
                        setActiveChannel(server.channels[0].id);
                      }
                    }}
                  >
                    {server.imageUrl ? (
                      <img
                        src={server.imageUrl}
                        alt={server.name}
                        className="w-full h-full rounded-[inherit] object-cover"
                      />
                    ) : (
                      server.name
                        .split(" ")
                        .map((w) => w[0])
                        .join("")
                        .slice(0, 3)
                        .toUpperCase()
                    )}
                  </button>
                </TooltipTrigger>
                <TooltipContent side="right">{server.name}</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </ScrollArea>

      <div className="w-8 h-[2px] bg-[#35363c] rounded-full" />

      {/* Add server button */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <DialogTrigger asChild>
                <button className="w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 bg-[#313338] hover:bg-[#23a559] flex items-center justify-center text-[#dbdee1] hover:text-white">
                  <Plus className="w-6 h-6" />
                </button>
              </DialogTrigger>
            </TooltipTrigger>
            <TooltipContent side="right">Add a Server</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <DialogContent className="bg-[#313338] text-white border-none">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">
              Create a Server
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-[#949ba4] text-center -mt-1">
            Your server is where you and your friends hang out.
          </p>
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-xs font-semibold text-[#949ba4] uppercase">
                Server Name
              </label>
              <Input
                placeholder="My Awesome Server"
                value={serverName}
                onChange={(e) => setServerName(e.target.value)}
                className="bg-[#1e1f22] border-[#383a40] text-white mt-1"
              />
            </div>
            <Button
              onClick={handleCreateServer}
              disabled={creating || !serverName.trim()}
              className="w-full bg-[#23a559] hover:bg-[#1a8f4a] text-white"
            >
              {creating ? "Creating..." : "Create Server"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Join server button */}
      <Dialog
        open={showJoin}
        onOpenChange={(open) => {
          setShowJoin(open);
          if (!open) {
            setJoinError("");
            setJoinSuccess("");
          }
        }}
      >
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 bg-[#313338] hover:bg-[#23a559] flex items-center justify-center text-[#dbdee1] hover:text-white"
                onClick={() => setShowJoin(true)}
              >
                <UserPlus className="w-5 h-5" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">Join a Server</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <DialogContent className="bg-[#313338] text-white border-none">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">
              Join a Server
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-[#949ba4] text-center -mt-1">
            Enter an invite code to join an existing server.
          </p>
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-xs font-semibold text-[#949ba4] uppercase">
                Invite Code
              </label>
              <Input
                placeholder="Paste invite code here..."
                value={inviteCode}
                onChange={(e) => {
                  setInviteCode(e.target.value);
                  setJoinError("");
                  setJoinSuccess("");
                }}
                className="bg-[#1e1f22] border-[#383a40] text-white mt-1 font-mono"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && inviteCode.trim()) {
                    handleJoinServer();
                  }
                }}
              />
            </div>

            {/* Error message */}
            {joinError && (
              <div className="flex items-center gap-2 bg-[#f23f42]/10 border border-[#f23f42]/30 rounded px-3 py-2">
                <AlertCircle className="w-4 h-4 text-[#f23f42] shrink-0" />
                <p className="text-sm text-[#f23f42]">{joinError}</p>
              </div>
            )}

            {/* Success message */}
            {joinSuccess && (
              <div className="flex items-center gap-2 bg-[#23a559]/10 border border-[#23a559]/30 rounded px-3 py-2">
                <CheckCircle2 className="w-4 h-4 text-[#23a559] shrink-0" />
                <p className="text-sm text-[#23a559]">{joinSuccess}</p>
              </div>
            )}

            <Button
              onClick={handleJoinServer}
              disabled={joining || !inviteCode.trim()}
              className="w-full bg-[#23a559] hover:bg-[#1a8f4a] text-white"
            >
              {joining ? "Joining..." : "Join Server"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
