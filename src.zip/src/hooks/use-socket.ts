"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import { useChatStore } from "@/stores/chat-store";
import type { ChatMessage } from "@/stores/chat-store";

const SOCKET_PORT = 3003;

// On Railway, use NEXT_PUBLIC_SOCKET_URL env var pointing to chat service
// On local dev, use the Caddy proxy with XTransformPort
function getSocketUrl() {
  const externalUrl = process.env.NEXT_PUBLIC_SOCKET_URL;
  if (externalUrl) {
    return externalUrl; // e.g., "https://chat-service-production-xxxx.up.railway.app"
  }
  // Local dev: use same origin with Caddy proxy
  return undefined; // will use relative path with XTransformPort
}

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const {
    userId,
    username,
    displayName,
    addMessage,
    addTypingUser,
    removeTypingUser,
    setOnlineUsers,
    addOnlineUser,
    removeOnlineUser,
    setVideoParticipants,
    addVideoParticipant,
    removeVideoParticipant,
    setScreenSharingUser,
  } = useChatStore();

  useEffect(() => {
    const socketUrl = getSocketUrl();
    const socketOptions: any = {
      transports: ["websocket", "polling"],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      timeout: 10000,
    };

    let socketInstance: Socket;
    if (socketUrl) {
      // Railway: connect directly to chat service URL
      socketInstance = io(socketUrl, socketOptions);
    } else {
      // Local dev: use Caddy proxy with XTransformPort
      socketInstance = io(`/?XTransformPort=${SOCKET_PORT}`, socketOptions);
    }

    socketRef.current = socketInstance;

    socketInstance.on("connect", () => {
      setIsConnected(true);
      // Re-authenticate on reconnect
      if (userId && username) {
        socketInstance.emit("auth", { userId, username, displayName });
      }
    });

    socketInstance.on("disconnect", () => {
      setIsConnected(false);
    });

    // Chat events
    socketInstance.on("new-message", (data: any) => {
      const message: ChatMessage = {
        id: data.messageId,
        content: data.content,
        channelId: data.channelId,
        senderId: data.sender.id,
        createdAt: data.createdAt,
        sender: data.sender,
      };
      addMessage(data.channelId, message);
    });

    socketInstance.on("user-typing", (data: any) => {
      addTypingUser(data.channelId, {
        userId: data.user.userId,
        username: data.user.username,
        displayName: data.user.displayName,
      });
    });

    socketInstance.on("user-stop-typing", (data: any) => {
      removeTypingUser(data.channelId, data.userId);
    });

    // Channel presence
    socketInstance.on("channel-users", (data: any) => {
      setOnlineUsers(data.channelId, data.users);
    });

    socketInstance.on("user-joined-channel", (data: any) => {
      addOnlineUser(data.channelId, data.user);
    });

    socketInstance.on("user-left-channel", (data: any) => {
      removeOnlineUser(data.channelId, data.user.userId);
    });

    // Video call events
    socketInstance.on("video-participants", (data: any) => {
      setVideoParticipants(data.participants);
    });

    socketInstance.on("user-joined-video", (data: any) => {
      addVideoParticipant(data.user);
    });

    socketInstance.on("user-left-video", (data: any) => {
      removeVideoParticipant(data.socketId);
    });

    socketInstance.on("screen-share-started", (data: any) => {
      setScreenSharingUser(data.socketId);
    });

    socketInstance.on("screen-share-stopped", () => {
      setScreenSharingUser(null);
    });

    return () => {
      socketInstance.disconnect();
    };
  }, [
    userId,
    username,
    displayName,
    addMessage,
    addTypingUser,
    removeTypingUser,
    setOnlineUsers,
    addOnlineUser,
    removeOnlineUser,
    setVideoParticipants,
    addVideoParticipant,
    removeVideoParticipant,
    setScreenSharingUser,
  ]);

  const getSocket = useCallback(() => socketRef.current, []);

  const joinChannel = useCallback(
    (channelId: string, serverId: string) => {
      socketRef.current?.emit("join-channel", { channelId, serverId });
    },
    []
  );

  const leaveChannel = useCallback((channelId: string) => {
    socketRef.current?.emit("leave-channel", { channelId });
  }, []);

  const sendMessage = useCallback(
    (channelId: string, content: string, sender: any) => {
      const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      socketRef.current?.emit("send-message", {
        channelId,
        messageId,
        content,
        sender,
        createdAt: new Date().toISOString(),
      });
    },
    []
  );

  const emitTyping = useCallback(
    (channelId: string, user: { userId: string; username: string; displayName: string }) => {
      socketRef.current?.emit("typing", { channelId, user });
    },
    []
  );

  const emitStopTyping = useCallback((channelId: string, userId: string) => {
    socketRef.current?.emit("stop-typing", { channelId, userId });
  }, []);

  // Video call methods
  const joinVideo = useCallback((channelId: string) => {
    socketRef.current?.emit("join-video", { channelId });
  }, []);

  const leaveVideo = useCallback((channelId: string) => {
    socketRef.current?.emit("leave-video", { channelId });
  }, []);

  const sendOffer = useCallback(
    (channelId: string, targetSocketId: string, offer: RTCSessionDescriptionInit) => {
      socketRef.current?.emit("webrtc-offer", { channelId, targetSocketId, offer });
    },
    []
  );

  const sendAnswer = useCallback(
    (channelId: string, targetSocketId: string, answer: RTCSessionDescriptionInit) => {
      socketRef.current?.emit("webrtc-answer", { channelId, targetSocketId, answer });
    },
    []
  );

  const sendIceCandidate = useCallback(
    (channelId: string, targetSocketId: string, candidate: RTCIceCandidateInit) => {
      socketRef.current?.emit("webrtc-ice-candidate", { channelId, targetSocketId, candidate });
    },
    []
  );

  const startScreenShare = useCallback((channelId: string) => {
    socketRef.current?.emit("screen-share-start", { channelId });
  }, []);

  const stopScreenShare = useCallback((channelId: string) => {
    socketRef.current?.emit("screen-share-stop", { channelId });
  }, []);

  // Register WebRTC event listeners
  const registerWebRTCListeners = useCallback(
    (handlers: {
      onOffer?: (data: any) => void;
      onAnswer?: (data: any) => void;
      onIceCandidate?: (data: any) => void;
      onUserJoinedVideo?: (data: any) => void;
      onUserLeftVideo?: (data: any) => void;
      onScreenShareStarted?: (data: any) => void;
      onScreenShareStopped?: (data: any) => void;
    }) => {
      const socket = socketRef.current;
      if (!socket) return () => {};

      if (handlers.onOffer) socket.on("webrtc-offer", handlers.onOffer);
      if (handlers.onAnswer) socket.on("webrtc-answer", handlers.onAnswer);
      if (handlers.onIceCandidate) socket.on("webrtc-ice-candidate", handlers.onIceCandidate);
      if (handlers.onUserJoinedVideo) socket.on("user-joined-video", handlers.onUserJoinedVideo);
      if (handlers.onUserLeftVideo) socket.on("user-left-video", handlers.onUserLeftVideo);
      if (handlers.onScreenShareStarted) socket.on("screen-share-started", handlers.onScreenShareStarted);
      if (handlers.onScreenShareStopped) socket.on("screen-share-stopped", handlers.onScreenShareStopped);

      return () => {
        if (handlers.onOffer) socket.off("webrtc-offer", handlers.onOffer);
        if (handlers.onAnswer) socket.off("webrtc-answer", handlers.onAnswer);
        if (handlers.onIceCandidate) socket.off("webrtc-ice-candidate", handlers.onIceCandidate);
        if (handlers.onUserJoinedVideo) socket.off("user-joined-video", handlers.onUserJoinedVideo);
        if (handlers.onUserLeftVideo) socket.off("user-left-video", handlers.onUserLeftVideo);
        if (handlers.onScreenShareStarted) socket.off("screen-share-started", handlers.onScreenShareStarted);
        if (handlers.onScreenShareStopped) socket.off("screen-share-stopped", handlers.onScreenShareStopped);
      };
    },
    []
  );

  return {
    getSocket,
    isConnected,
    joinChannel,
    leaveChannel,
    sendMessage,
    emitTyping,
    emitStopTyping,
    joinVideo,
    leaveVideo,
    sendOffer,
    sendAnswer,
    sendIceCandidate,
    startScreenShare,
    stopScreenShare,
    registerWebRTCListeners,
  };
}
