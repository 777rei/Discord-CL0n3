"use client";

import { useEffect, useState, useCallback } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import { useChatStore } from "@/stores/chat-store";
import { useSocket } from "@/hooks/use-socket";
import { ServerList } from "@/components/chat/server-list";
import { ChannelList } from "@/components/chat/channel-list";
import { ChatArea } from "@/components/chat/chat-area";
import { MemberList } from "@/components/chat/member-list";
import { VideoCallPanel } from "@/components/video/video-call-panel";
import { LoginForm } from "@/components/auth/login-form";
import { RegisterForm } from "@/components/auth/register-form";
import { Toaster } from "@/components/ui/toaster";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const { data: session, status } = useSession();
  const [showRegister, setShowRegister] = useState(false);

  const {
    isAuthenticated,
    setAuth,
    clearAuth,
    setServers,
    activeServerId,
    activeChannelId,
    setActiveServer,
    setActiveChannel,
    showMobileSidebar,
    showMobileMembers,
    setShowMobileSidebar,
    setShowMobileMembers,
  } = useChatStore();

  const { isConnected: socketConnected } = useSocket();

  // Sync auth state with session
  useEffect(() => {
    if (status === "authenticated" && session?.user) {
      const userId = (session.user as any).id;
      const username = (session.user as any).username || session.user.name;
      setAuth(userId, username, username);
    } else if (status === "unauthenticated") {
      clearAuth();
    }
  }, [session, status, setAuth, clearAuth]);

  // Load servers when authenticated
  useEffect(() => {
    if (!isAuthenticated) return;

    const loadServers = async () => {
      try {
        const res = await fetch("/api/servers");
        if (res.ok) {
          const servers = await res.json();
          setServers(servers);
          // Auto-select first server and channel
          if (servers.length > 0 && !activeServerId) {
            setActiveServer(servers[0].id);
            if (servers[0].channels?.length > 0) {
              setActiveChannel(servers[0].channels[0].id);
            }
          }
        }
      } catch (err) {
        console.error("Load servers error:", err);
      }
    };

    loadServers();
  }, [isAuthenticated, setServers, activeServerId, setActiveServer, setActiveChannel]);

  const handleAuthSuccess = useCallback(() => {
    // Trigger session refresh
    window.location.reload();
  }, []);

  // Loading state
  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#313338]">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 text-[#23a559] animate-spin mx-auto" />
          <p className="text-[#949ba4]">Loading...</p>
        </div>
      </div>
    );
  }

  // Auth screens
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#313338]">
        {showRegister ? (
          <RegisterForm
            onSuccess={handleAuthSuccess}
            onSwitchToLogin={() => setShowRegister(false)}
          />
        ) : (
          <LoginForm
            onSuccess={handleAuthSuccess}
            onSwitchToRegister={() => setShowRegister(true)}
          />
        )}
      </div>
    );
  }

  // Main app layout
  return (
    <div className="h-screen flex flex-col bg-[#313338] overflow-hidden">
      {/* Main content area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Server sidebar - always visible on desktop, toggle on mobile */}
        <div
          className={`${
            showMobileSidebar ? "flex" : "hidden"
          } md:flex lg:flex`}
        >
          <ServerList />
        </div>

        {/* Channel sidebar */}
        <div
          className={`${
            showMobileSidebar ? "flex" : "hidden"
          } md:flex lg:flex`}
        >
          <ChannelList />
        </div>

        {/* Main chat area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Mobile header with hamburger */}
          <div className="md:hidden h-12 bg-[#313338] flex items-center px-4 border-b border-[#1f2023]">
            <button
              onClick={() => setShowMobileSidebar(!showMobileSidebar)}
              className="text-[#949ba4] hover:text-white mr-3"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
            <span className="text-white font-semibold text-sm truncate">
              {activeServerId
                ? useChatStore
                    .getState()
                    .servers.find((s) => s.id === activeServerId)?.name ||
                  "Discord Clone"
                : "Discord Clone"}
            </span>
            <button
              className="ml-auto text-[#949ba4] hover:text-white"
              onClick={() => setShowMobileMembers(!showMobileMembers)}
            >
              <svg
                className="w-5 h-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                />
              </svg>
            </button>
          </div>

          <div className="flex-1 flex overflow-hidden">
            <ChatArea />

            {/* Member list */}
            <div
              className={`${
                showMobileMembers ? "flex" : "hidden"
              } lg:flex`}
            >
              <MemberList />
            </div>
          </div>
        </div>
      </div>

      {/* Video call panel (shows when in a voice channel or in a call) */}
      <VideoCallPanel />

      {/* Connection status indicator */}
      {!socketConnected && isAuthenticated && (
        <div className="fixed bottom-4 left-4 bg-[#f23f42] text-white px-4 py-2 rounded-lg text-sm font-medium z-50 shadow-lg">
          Reconnecting...
        </div>
      )}
    </div>
  );
}
