import { create } from 'zustand'

export interface ServerChannel {
  id: string
  name: string
  type: string
  createdAt: string
  updatedAt: string
}

export interface ServerMember {
  id: string
  userId: string
  role: string
  user: {
    id: string
    username: string
    displayName: string
    avatarUrl: string | null
    status: string
  }
}

export interface Server {
  id: string
  name: string
  imageUrl: string | null
  inviteCode: string
  ownerId: string
  channels: ServerChannel[]
  members: ServerMember[]
  owner: {
    id: string
    username: string
    displayName: string
  }
}

export interface ChatMessage {
  id: string
  content: string
  channelId: string
  senderId: string
  createdAt: string
  sender: {
    id: string
    username: string
    displayName: string
    avatarUrl: string | null
  }
}

export interface VideoParticipant {
  socketId: string
  userId: string
  username: string
  displayName: string
  avatarUrl: string | null
}

interface ChatState {
  // Auth
  isAuthenticated: boolean
  userId: string | null
  username: string | null
  displayName: string | null

  // Servers
  servers: Server[]
  activeServerId: string | null
  activeChannelId: string | null

  // Messages
  messages: Record<string, ChatMessage[]> // channelId -> messages
  typingUsers: Record<string, { userId: string; username: string; displayName: string }[]> // channelId -> users

  // Video
  videoChannelId: string | null
  videoParticipants: VideoParticipant[]
  isInCall: boolean
  isScreenSharing: boolean
  screenSharingUser: string | null // socketId

  // Online users in channel
  onlineUsers: Record<string, { userId: string; username: string; displayName: string; avatarUrl: string | null }[]> // channelId -> users

  // Mobile
  showMobileSidebar: boolean
  showMobileMembers: boolean

  // Actions
  setAuth: (userId: string, username: string, displayName: string) => void
  clearAuth: () => void
  setServers: (servers: Server[]) => void
  addServer: (server: Server) => void
  setActiveServer: (serverId: string) => void
  setActiveChannel: (channelId: string) => void
  addMessage: (channelId: string, message: ChatMessage) => void
  setMessages: (channelId: string, messages: ChatMessage[]) => void
  addTypingUser: (channelId: string, user: { userId: string; username: string; displayName: string }) => void
  removeTypingUser: (channelId: string, userId: string) => void
  setVideoChannel: (channelId: string | null) => void
  setVideoParticipants: (participants: VideoParticipant[]) => void
  addVideoParticipant: (participant: VideoParticipant) => void
  removeVideoParticipant: (socketId: string) => void
  setIsInCall: (inCall: boolean) => void
  setIsScreenSharing: (sharing: boolean) => void
  setScreenSharingUser: (socketId: string | null) => void
  setOnlineUsers: (channelId: string, users: { userId: string; username: string; displayName: string; avatarUrl: string | null }[]) => void
  addOnlineUser: (channelId: string, user: { userId: string; username: string; displayName: string; avatarUrl: string | null }) => void
  removeOnlineUser: (channelId: string, userId: string) => void
  setShowMobileSidebar: (show: boolean) => void
  setShowMobileMembers: (show: boolean) => void
}

export const useChatStore = create<ChatState>((set) => ({
  isAuthenticated: false,
  userId: null,
  username: null,
  displayName: null,

  servers: [],
  activeServerId: null,
  activeChannelId: null,

  messages: {},
  typingUsers: {},

  videoChannelId: null,
  videoParticipants: [],
  isInCall: false,
  isScreenSharing: false,
  screenSharingUser: null,

  onlineUsers: {},

  showMobileSidebar: false,
  showMobileMembers: false,

  setAuth: (userId, username, displayName) => set({ isAuthenticated: true, userId, username, displayName }),
  clearAuth: () => set({ isAuthenticated: false, userId: null, username: null, displayName: null }),

  setServers: (servers) => set({ servers }),
  addServer: (server) => set((state) => ({ servers: [...state.servers, server] })),

  setActiveServer: (serverId) => set({ activeServerId: serverId }),
  setActiveChannel: (channelId) => set({ activeChannelId: channelId }),

  addMessage: (channelId, message) => set((state) => ({
    messages: {
      ...state.messages,
      [channelId]: [...(state.messages[channelId] || []), message],
    },
  })),

  setMessages: (channelId, messages) => set((state) => ({
    messages: {
      ...state.messages,
      [channelId]: messages,
    },
  })),

  addTypingUser: (channelId, user) => set((state) => {
    const current = state.typingUsers[channelId] || []
    if (current.find(u => u.userId === user.userId)) return state
    return {
      typingUsers: {
        ...state.typingUsers,
        [channelId]: [...current, user],
      },
    }
  }),

  removeTypingUser: (channelId, userId) => set((state) => ({
    typingUsers: {
      ...state.typingUsers,
      [channelId]: (state.typingUsers[channelId] || []).filter(u => u.userId !== userId),
    },
  })),

  setVideoChannel: (channelId) => set({ videoChannelId: channelId, isInCall: channelId !== null }),
  setVideoParticipants: (participants) => set({ videoParticipants: participants }),
  addVideoParticipant: (participant) => set((state) => ({
    videoParticipants: [...state.videoParticipants, participant],
  })),
  removeVideoParticipant: (socketId) => set((state) => ({
    videoParticipants: state.videoParticipants.filter(p => p.socketId !== socketId),
  })),
  setIsInCall: (inCall) => set({ isInCall: inCall }),
  setIsScreenSharing: (sharing) => set({ isScreenSharing: sharing }),
  setScreenSharingUser: (socketId) => set({ screenSharingUser: socketId }),

  setOnlineUsers: (channelId, users) => set((state) => ({
    onlineUsers: { ...state.onlineUsers, [channelId]: users },
  })),
  addOnlineUser: (channelId, user) => set((state) => {
    const current = state.onlineUsers[channelId] || []
    if (current.find(u => u.userId === user.userId)) return state
    return {
      onlineUsers: { ...state.onlineUsers, [channelId]: [...current, user] },
    }
  }),
  removeOnlineUser: (channelId, userId) => set((state) => ({
    onlineUsers: {
      ...state.onlineUsers,
      [channelId]: (state.onlineUsers[channelId] || []).filter(u => u.userId !== userId),
    },
  })),

  setShowMobileSidebar: (show) => set({ showMobileSidebar: show }),
  setShowMobileMembers: (show) => set({ showMobileMembers: show }),
}))
