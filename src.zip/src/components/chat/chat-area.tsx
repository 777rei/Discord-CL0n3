"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useChatStore } from "@/stores/chat-store";
import { useSocket } from "@/hooks/use-socket";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Hash,
  Volume2,
  Users,
  PlusCircle,
  Gift,
  Smile,
  Sticker,
  Phone,
  Video,
  Pin,
  Bell,
  Search,
  Inbox,
  HelpCircle,
  Send,
} from "lucide-react";

export function ChatArea() {
  const {
    servers,
    activeServerId,
    activeChannelId,
    messages,
    typingUsers,
    userId,
    username,
    displayName,
    onlineUsers,
    setShowMobileMembers,
  } = useChatStore();

  const {
    isConnected,
    joinChannel,
    leaveChannel,
    sendMessage,
    emitTyping,
    emitStopTyping,
  } = useSocket();

  const [inputMessage, setInputMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const prevChannelRef = useRef<string | null>(null);

  const activeServer = servers.find((s) => s.id === activeServerId);
  const activeChannel = activeServer?.channels.find(
    (c) => c.id === activeChannelId
  );

  const channelMessages = activeChannelId
    ? messages[activeChannelId] || []
    : [];

  const channelTypingUsers = activeChannelId
    ? typingUsers[activeChannelId] || []
    : [];

  // Join/leave channel via socket
  useEffect(() => {
    if (activeChannelId && activeServerId && isConnected) {
      if (prevChannelRef.current && prevChannelRef.current !== activeChannelId) {
        leaveChannel(prevChannelRef.current);
      }
      joinChannel(activeChannelId, activeServerId);
      prevChannelRef.current = activeChannelId;
    }

    return () => {
      if (prevChannelRef.current) {
        leaveChannel(prevChannelRef.current);
        prevChannelRef.current = null;
      }
    };
  }, [activeChannelId, activeServerId, isConnected, joinChannel, leaveChannel]);

  // Load messages from API
  useEffect(() => {
    if (!activeChannelId) return;

    const loadMessages = async () => {
      setLoading(true);
      try {
        const res = await fetch(
          `/api/channels/${activeChannelId}/messages`
        );
        if (res.ok) {
          const data = await res.json();
          useChatStore
            .getState()
            .setMessages(activeChannelId, data.messages);
        }
      } catch (err) {
        console.error("Load messages error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadMessages();
  }, [activeChannelId]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [channelMessages]);

  const handleSendMessage = useCallback(() => {
    if (!inputMessage.trim() || !activeChannelId || !userId) return;

    sendMessage(activeChannelId, inputMessage.trim(), {
      id: userId,
      username,
      displayName,
    });

    // Also save to DB
    fetch(`/api/channels/${activeChannelId}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: inputMessage.trim() }),
    }).catch((err) => console.error("Save message error:", err));

    setInputMessage("");
    emitStopTyping(activeChannelId, userId!);
  }, [
    inputMessage,
    activeChannelId,
    userId,
    username,
    displayName,
    sendMessage,
    emitStopTyping,
  ]);

  const handleInputChange = useCallback(
    (value: string) => {
      setInputMessage(value);

      if (activeChannelId && userId && value.length > 0) {
        emitTyping(activeChannelId, {
          userId,
          username: username || "",
          displayName: displayName || "",
        });

        // Clear previous timeout
        if (typingTimeoutRef.current) {
          clearTimeout(typingTimeoutRef.current);
        }

        // Set new timeout to stop typing
        typingTimeoutRef.current = setTimeout(() => {
          emitStopTyping(activeChannelId, userId);
        }, 3000);
      }
    },
    [activeChannelId, userId, username, displayName, emitTyping, emitStopTyping]
  );

  const formatTimestamp = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const isToday =
      date.toDateString() === now.toDateString();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const isYesterday =
      date.toDateString() === yesterday.toDateString();

    if (isToday) {
      return `Today at ${date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      })}`;
    }
    if (isYesterday) {
      return `Yesterday at ${date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      })}`;
    }
    return date.toLocaleDateString([], {
      month: "2-digit",
      day: "2-digit",
      year: "numeric",
    }) +
      " " +
      date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
  };

  // Group messages by date
  const groupedMessages: { date: string; messages: typeof channelMessages }[] =
    [];
  let currentDate = "";
  for (const msg of channelMessages) {
    const msgDate = new Date(msg.createdAt).toLocaleDateString();
    if (msgDate !== currentDate) {
      currentDate = msgDate;
      groupedMessages.push({ date: msgDate, messages: [msg] });
    } else {
      groupedMessages[groupedMessages.length - 1].messages.push(msg);
    }
  }

  if (!activeChannel) {
    return (
      <div className="flex-1 bg-[#313338] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-48 h-48 mx-auto opacity-40">
            <svg viewBox="0 0 24 24" fill="#dbdee1">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
            </svg>
          </div>
          <p className="text-[#949ba4] text-lg">
            No channel selected
          </p>
          <p className="text-[#949ba4] text-sm">
            Select a server and channel to start chatting
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-[#313338] flex flex-col min-w-0">
      {/* Channel header */}
      <div className="h-12 px-4 flex items-center border-b border-[#1f2023] shadow-sm shrink-0">
        {activeChannel.type === "voice" ? (
          <Volume2 className="w-5 h-5 text-[#949ba4] mr-2 shrink-0" />
        ) : (
          <Hash className="w-5 h-5 text-[#949ba4] mr-2 shrink-0" />
        )}
        <span className="font-semibold text-white">
          {activeChannel.name}
        </span>
        {activeChannel.type === "text" && (
          <div className="ml-4 h-6 w-px bg-[#3f4147]" />
        )}
        {activeChannel.type === "text" && (
          <span className="ml-4 text-sm text-[#949ba4] truncate">
            Welcome to #{activeChannel.name}!
          </span>
        )}
        <div className="ml-auto flex items-center gap-3 text-[#949ba4]">
          <button className="hover:text-[#dbdee1]">
            <Bell className="w-5 h-5" />
          </button>
          <button className="hover:text-[#dbdee1]">
            <Pin className="w-5 h-5" />
          </button>
          <button className="hover:text-[#dbdee1]">
            <Users
              className="w-5 h-5 lg:hidden"
              onClick={() => setShowMobileMembers(true)}
            />
          </button>
          <div className="hidden lg:flex items-center bg-[#1e1f22] rounded px-1.5">
            <Input
              placeholder="Search"
              className="h-6 w-36 bg-transparent border-none text-sm text-[#dbdee1] placeholder:text-[#949ba4] focus-visible:ring-0 p-0"
            />
            <Search className="w-4 h-4 text-[#949ba4]" />
          </div>
          <button className="hover:text-[#dbdee1]">
            <Inbox className="w-5 h-5" />
          </button>
          <button className="hover:text-[#dbdee1]">
            <HelpCircle className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages area */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-4">
          {/* Channel welcome */}
          <div className="mb-4 pt-8">
            <div className="w-16 h-16 rounded-full bg-[#41434a] flex items-center justify-center mb-2">
              {activeChannel.type === "voice" ? (
                <Volume2 className="w-10 h-10 text-white" />
              ) : (
                <Hash className="w-10 h-10 text-white" />
              )}
            </div>
            <h1 className="text-3xl font-bold text-white mb-1">
              Welcome to #{activeChannel.name}!
            </h1>
            <p className="text-[#949ba4]">
              This is the start of the #{activeChannel.name} channel.
            </p>
          </div>

          {loading && (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-3 animate-pulse">
                  <div className="w-10 h-10 rounded-full bg-[#41434a]" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-32 bg-[#41434a] rounded" />
                    <div className="h-4 w-64 bg-[#41434a] rounded" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Message groups */}
          {groupedMessages.map((group, gi) => (
            <div key={gi}>
              {/* Date divider */}
              <div className="flex items-center my-4">
                <div className="flex-1 h-px bg-[#3f4147]" />
                <span className="px-2 text-xs font-semibold text-[#949ba4]">
                  {new Date(group.date).toLocaleDateString([], {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <div className="flex-1 h-px bg-[#3f4147]" />
              </div>

              {group.messages.map((msg, mi) => {
                const isOwnMessage = msg.senderId === userId;
                const prevMsg =
                  mi > 0 ? group.messages[mi - 1] : null;
                const isSameSender =
                  prevMsg && prevMsg.senderId === msg.senderId;

                if (isSameSender) {
                  return (
                    <div
                      key={msg.id}
                      className="group flex gap-4 pl-[52px] hover:bg-[#2e3035] -mt-0.5 py-0.5 px-4"
                    >
                      <div className="w-[52px] shrink-0 flex items-start justify-center pt-0.5">
                        <span className="text-[11px] text-[#949ba4] opacity-0 group-hover:opacity-100">
                          {new Date(msg.createdAt).toLocaleTimeString(
                            [],
                            {
                              hour: "2-digit",
                              minute: "2-digit",
                            }
                          )}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[#dbdee1] text-[15px] break-words">
                          {msg.content}
                        </p>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className="group flex gap-4 hover:bg-[#2e3035] py-1 px-4"
                  >
                    <Avatar className="w-10 h-10 shrink-0">
                      <AvatarImage src={msg.sender.avatarUrl || ""} />
                      <AvatarFallback className="bg-[#23a559] text-white text-sm font-semibold">
                        {msg.sender.displayName?.[0]?.toUpperCase() ||
                          msg.sender.username?.[0]?.toUpperCase() ||
                          "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span
                          className={`font-medium text-[15px] cursor-pointer hover:underline ${
                            isOwnMessage ? "text-[#23a559]" : "text-[#f2f3f5]"
                          }`}
                        >
                          {msg.sender.displayName || msg.sender.username}
                        </span>
                        <span className="text-[11px] text-[#949ba4]">
                          {formatTimestamp(msg.createdAt)}
                        </span>
                      </div>
                      <p className="text-[#dbdee1] text-[15px] break-words">
                        {msg.content}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Typing indicator */}
      {channelTypingUsers.length > 0 && (
        <div className="px-4 h-6 flex items-center">
          <span className="text-xs text-[#949ba4]">
            <span className="flex gap-0.5 mr-1 inline-flex">
              <span className="animate-bounce" style={{ animationDelay: "0ms" }}>
                .
              </span>
              <span className="animate-bounce" style={{ animationDelay: "150ms" }}>
                .
              </span>
              <span className="animate-bounce" style={{ animationDelay: "300ms" }}>
                .
              </span>
            </span>
            <strong>{channelTypingUsers[0]?.displayName}</strong>
            {channelTypingUsers.length > 1 &&
              ` and ${channelTypingUsers.length - 1} others`}
            {" "}
            {channelTypingUsers.length === 1 ? "is" : "are"} typing...
          </span>
        </div>
      )}

      {/* Message input */}
      {activeChannel.type === "text" && (
        <div className="px-4 pb-6 pt-0">
          <div className="flex items-center bg-[#383a40] rounded-lg px-4">
            <button className="text-[#949ba4] hover:text-[#dbdee1] shrink-0">
              <PlusCircle className="w-6 h-6" />
            </button>
            <Input
              placeholder={`Message #${activeChannel.name}`}
              value={inputMessage}
              onChange={(e) => handleInputChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              className="flex-1 border-none bg-transparent text-[#dbdee1] placeholder:text-[#6d6f78] focus-visible:ring-0 py-3 text-[15px]"
            />
            <div className="flex items-center gap-2 text-[#949ba4] shrink-0">
              <button className="hover:text-[#dbdee1]">
                <Gift className="w-6 h-6" />
              </button>
              <button className="hover:text-[#dbdee1]">
                <Sticker className="w-5 h-5" />
              </button>
              <button className="hover:text-[#dbdee1]">
                <Smile className="w-6 h-6" />
              </button>
              {inputMessage.trim() && (
                <button
                  className="text-[#949ba4] hover:text-white"
                  onClick={handleSendMessage}
                >
                  <Send className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Voice channel - show join voice button */}
      {activeChannel.type === "voice" && (
        <div className="px-4 pb-6 pt-0">
          <div className="flex items-center justify-center gap-3 py-8">
            <p className="text-[#949ba4]">
              Voice channel - use the video panel to join
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
