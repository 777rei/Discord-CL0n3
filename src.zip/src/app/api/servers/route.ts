import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = (session.user as any).id;

    const servers = await db.server.findMany({
      where: {
        members: {
          some: { userId },
        },
      },
      include: {
        channels: {
          orderBy: { createdAt: "asc" },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                displayName: true,
                avatarUrl: true,
                status: true,
              },
            },
          },
        },
        owner: {
          select: {
            id: true,
            username: true,
            displayName: true,
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });

    return NextResponse.json(servers);
  } catch (error) {
    console.error("Get servers error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = (session.user as any).id;
    const body = await req.json();
    const { name, imageUrl } = body;

    if (!name || name.trim().length === 0) {
      return NextResponse.json(
        { error: "Server name is required" },
        { status: 400 }
      );
    }

    const server = await db.server.create({
      data: {
        name: name.trim(),
        imageUrl: imageUrl || null,
        ownerId: userId,
        members: {
          create: {
            userId,
            role: "owner",
          },
        },
        channels: {
          createMany: {
            data: [
              { name: "general", type: "text" },
              { name: "random", type: "text" },
              { name: "General Voice", type: "voice" },
            ],
          },
        },
      },
      include: {
        channels: true,
        members: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                displayName: true,
                avatarUrl: true,
                status: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json(server, { status: 201 });
  } catch (error) {
    console.error("Create server error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
