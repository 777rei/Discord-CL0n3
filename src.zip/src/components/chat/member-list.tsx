"use client";

import { useChatStore } from "@/stores/chat-store";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Hash, Volume2, Crown, Shield } from "lucide-react";

export function MemberList() {
  const { servers, activeServerId, onlineUsers, activeChannelId } =
    useChatStore();

  const activeServer = servers.find((s) => s.id === activeServerId);
  const members = activeServer?.members || [];

  const online = members.filter(
    (m) =>
      m.user.status === "online" ||
      (activeChannelId && onlineUsers[activeChannelId]?.find((u) => u.userId === m.userId))
  );
  const offline = members.filter(
    (m) =>
      m.user.status !== "online" &&
      !(activeChannelId && onlineUsers[activeChannelId]?.find((u) => u.userId === m.userId))
  );

  const getRoleIcon = (role: string) => {
    if (role === "owner") return <Crown className="w-3.5 h-3.5 text-[#f0b132]" />;
    if (role === "admin") return <Shield className="w-3.5 h-3.5 text-[#e91e63]" />;
    return null;
  };

  const getRoleName = (role: string) => {
    if (role === "owner") return "Owner";
    if (role === "admin") return "Admin";
    return "Member";
  };

  return (
    <div className="w-60 bg-[#2b2d31] hidden lg:flex flex-col shrink-0">
      <ScrollArea className="flex-1">
        <div className="p-3 space-y-4">
          {/* Online members */}
          {online.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-[#949ba4] uppercase tracking-wide px-1 mb-1">
                Online — {online.length}
              </p>
              {online.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center gap-3 px-1 py-1.5 rounded hover:bg-[#35373c] cursor-pointer group"
                >
                  <div className="relative shrink-0">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={member.user.avatarUrl || ""} />
                      <AvatarFallback className="bg-[#23a559] text-white text-xs font-semibold">
                        {member.user.displayName?.[0]?.toUpperCase() ||
                          member.user.username?.[0]?.toUpperCase() ||
                          "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-[3px] border-[#2b2d31] bg-[#23a559]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-medium text-[#f2f3f5] group-hover:text-white truncate">
                        {member.user.displayName || member.user.username}
                      </span>
                      {getRoleIcon(member.role)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Offline members */}
          {offline.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-[#949ba4] uppercase tracking-wide px-1 mb-1">
                Offline — {offline.length}
              </p>
              {offline.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center gap-3 px-1 py-1.5 rounded hover:bg-[#35373c] cursor-pointer group opacity-40"
                >
                  <div className="relative shrink-0">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={member.user.avatarUrl || ""} />
                      <AvatarFallback className="bg-[#41434a] text-[#949ba4] text-xs font-semibold">
                        {member.user.displayName?.[0]?.toUpperCase() ||
                          member.user.username?.[0]?.toUpperCase() ||
                          "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-[3px] border-[#2b2d31] bg-[#80848e]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-sm text-[#949ba4] truncate">
                      {member.user.displayName || member.user.username}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
