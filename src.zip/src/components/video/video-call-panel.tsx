"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useChatStore } from "@/stores/chat-store";
import { useSocket } from "@/hooks/use-socket";
import { useWebRTC } from "@/hooks/use-webrtc";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Monitor,
  MonitorOff,
  PhoneOff,
  Phone,
  Maximize2,
  Minimize2,
  X,
  Volume2,
} from "lucide-react";

export function VideoCallPanel() {
  const {
    activeChannelId,
    activeServerId,
    servers,
    isInCall,
    videoChannelId,
    videoParticipants,
    isScreenSharing: storeScreenSharing,
    screenSharingUser,
    setVideoChannel,
    setIsInCall,
  } = useChatStore();

  const { getSocket, isConnected, joinVideo, leaveVideo, registerWebRTCListeners } = useSocket();
  const {
    localStream,
    remoteStreams,
    isMuted,
    isVideoOff,
    isScreenSharing: localScreenSharing,
    startLocalStream,
    stopLocalStream,
    toggleMute,
    toggleVideo,
    startScreenSharing,
    stopScreenSharing,
    setupWebRTCSignaling,
  } = useWebRTC({ getSocket, channelId: videoChannelId });

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Set local video
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Set remote videos
  useEffect(() => {
    remoteStreams.forEach((stream, socketId) => {
      const videoEl = remoteVideoRefs.current.get(socketId);
      if (videoEl) {
        videoEl.srcObject = stream;
      }
    });
  }, [remoteStreams]);

  // Setup WebRTC signaling when in a call
  useEffect(() => {
    if (!isInCall || !videoChannelId) return;

    const cleanup = setupWebRTCSignaling(registerWebRTCListeners);
    return cleanup;
  }, [isInCall, videoChannelId, setupWebRTCSignaling, registerWebRTCListeners]);

  const handleJoinCall = useCallback(async () => {
    if (!activeChannelId) return;

    const stream = await startLocalStream();
    if (stream) {
      joinVideo(activeChannelId);
      setVideoChannel(activeChannelId);
      setIsInCall(true);
    }
  }, [activeChannelId, startLocalStream, joinVideo, setVideoChannel, setIsInCall]);

  const handleLeaveCall = useCallback(() => {
    if (videoChannelId) {
      leaveVideo(videoChannelId);
    }
    stopLocalStream();
    setVideoChannel(null);
    setIsInCall(false);
  }, [videoChannelId, leaveVideo, stopLocalStream, setVideoChannel, setIsInCall]);

  // Find voice channels in the active server
  const activeServer = servers.find((s) => s.id === activeServerId);
  const activeChannel = activeServer?.channels.find((c) => c.id === activeChannelId);

  // If not in a call and not in a voice channel, show nothing
  if (!isInCall && activeChannel?.type !== "voice") {
    return null;
  }

  // Show join call button if in voice channel but not in call
  if (!isInCall && activeChannel?.type === "voice") {
    return (
      <div className="bg-[#2b2d31] border-t border-[#1f2023] p-4">
        <div className="text-center space-y-3">
          <Volume2 className="w-12 h-12 text-[#23a559] mx-auto" />
          <h3 className="text-white font-semibold text-lg">
            {activeChannel.name}
          </h3>
          <p className="text-[#949ba4] text-sm">
            {videoParticipants.length} participant{videoParticipants.length !== 1 ? "s" : ""}
          </p>
          <Button
            onClick={handleJoinCall}
            className="bg-[#23a559] hover:bg-[#1a8f4a] text-white"
          >
            <Phone className="w-4 h-4 mr-2" />
            Join Call
          </Button>
        </div>
      </div>
    );
  }

  // Active call UI
  return (
    <div
      className={`bg-[#1e1f22] flex flex-col ${
        isFullscreen
          ? "fixed inset-0 z-50"
          : "border-t border-[#1f2023]"
      }`}
    >
      {/* Call header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#2b2d31]">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#23a559] animate-pulse" />
          <span className="text-white text-sm font-medium">
            Voice Call — {videoParticipants.length + 1} participant
            {videoParticipants.length !== 0 ? "s" : ""}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded hover:bg-[#35373c] text-[#949ba4] hover:text-white"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>
          {!isFullscreen && (
            <button
              onClick={handleLeaveCall}
              className="p-1.5 rounded hover:bg-[#f23f42] text-[#949ba4] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Video grid */}
      <div
        className={`flex-1 p-4 grid gap-2 ${
          videoParticipants.length === 0
            ? "grid-cols-1"
            : videoParticipants.length === 1
            ? "grid-cols-2"
            : videoParticipants.length <= 3
            ? "grid-cols-2"
            : "grid-cols-3"
        }`}
        style={{
          maxHeight: isFullscreen ? "calc(100vh - 120px)" : "360px",
        }}
      >
        {/* Local video */}
        <div className="relative bg-[#2b2d31] rounded-lg overflow-hidden aspect-video">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          {isVideoOff && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#2b2d31]">
              <Avatar className="w-20 h-20">
                <AvatarFallback className="bg-[#23a559] text-white text-2xl font-bold">
                  {useChatStore.getState().displayName?.[0]?.toUpperCase() || "?"}
                </AvatarFallback>
              </Avatar>
            </div>
          )}
          <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-0.5 rounded text-xs text-white">
            {useChatStore.getState().displayName}
            {localScreenSharing && " (Screen)"}
          </div>
        </div>

        {/* Remote videos */}
        {videoParticipants.map((participant) => (
          <div
            key={participant.socketId}
            className="relative bg-[#2b2d31] rounded-lg overflow-hidden aspect-video"
          >
            <video
              ref={(el) => {
                if (el) {
                  remoteVideoRefs.current.set(participant.socketId, el);
                  const stream = remoteStreams.get(participant.socketId);
                  if (stream) {
                    el.srcObject = stream;
                  }
                }
              }}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-0.5 rounded text-xs text-white">
              {participant.displayName}
              {screenSharingUser === participant.socketId && " (Screen)"}
            </div>
          </div>
        ))}
      </div>

      {/* Call controls */}
      <div className="flex items-center justify-center gap-2 py-3 px-4 bg-[#2b2d31]">
        <button
          onClick={toggleMute}
          className={`p-3 rounded-full ${
            isMuted
              ? "bg-[#f23f42] text-white"
              : "bg-[#3c3f44] text-white hover:bg-[#4e5058]"
          } transition-colors`}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        <button
          onClick={toggleVideo}
          className={`p-3 rounded-full ${
            isVideoOff
              ? "bg-[#f23f42] text-white"
              : "bg-[#3c3f44] text-white hover:bg-[#4e5058]"
          } transition-colors`}
        >
          {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
        </button>

        <button
          onClick={() => {
            if (localScreenSharing) {
              stopScreenSharing();
            } else {
              startScreenSharing();
            }
          }}
          className={`p-3 rounded-full ${
            localScreenSharing
              ? "bg-[#23a559] text-white"
              : "bg-[#3c3f44] text-white hover:bg-[#4e5058]"
          } transition-colors`}
        >
          {localScreenSharing ? (
            <MonitorOff className="w-5 h-5" />
          ) : (
            <Monitor className="w-5 h-5" />
          )}
        </button>

        <button
          onClick={handleLeaveCall}
          className="p-3 rounded-full bg-[#f23f42] text-white hover:bg-[#d83c3e] transition-colors"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
